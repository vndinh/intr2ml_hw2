function K = svmkernel(x_i, x_j,kernel_type)
%% Arguments %%
% x_i: ith random data from [m]
% x_j: j ~= i data from [m]
% kernel_type: kernel types : 'linear' or 'rbf'
%% Your code here %%
    switch kernel_type
      case 'linear'
          %linear kernel type
          K = x_i' * x_j;
      case 'rbf'
          %rbf kernel type
          sigma = 0.2;  % Covariance
          K = exp(-(norm(x_i-x_j))^2/(2*sigma^2));
      otherwise
        error('Unknown kernel function');
    end
    K = double(K);
end
% Convert to full matrix if inputs are sparse
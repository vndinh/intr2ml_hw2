function acc = test_rbf(x_test,y_test,x_train,alpha)
%% Argurments %%
% x_test: test data
% y_test: test label
% alpha : average alpha
% acc: accuracy
%% Your code here %%
% Evaluate x_test
num_test = length(x_test);          % The number of test data samples
num_train = length(x_train);        % The number of training data samples
y_test_result = zeros(num_test,1);  % Prediction label

for i = 1:num_test
    x_i = x_test(i,:);  % ith data sample

    % Estimate feature map
    y_sum = 0;
    for j = 1:num_train
        y_sum = y_sum + alpha(j) * svmkernel(x_i,x_train(j,:),'rbf');
    end
    yp = sign(y_sum);
    y_test_result(i) = yp;
end

% Calculate accuracy
acc = 100 * sum(y_test_result == y_test) / num_test;
fprintf('Accuracy of Kernel SVM: acc = %f %% \n', acc);

end
function prediction = estimate_svm_rbf(x_input,x_train,alpha)
%% Arguments%%
% x_input: grid of sample data
% x_train : training data
% alpha : average alpha vector
% prediction : sum of support vector algorithm
m = size(x_train,1);    % The training data size
n = size(x_input,1);    % The input data size
y_pred = zeros(n,1);    % Prediction label

for i = 1:n
    % ith data sample
    x_i = x_input(i,:);

    % Predict the label by using RBF kernel
    y_sum = 0;
    for j = 1:m
        y_sum = y_sum + alpha(j) * svmkernel(x_i,x_train(j,:),'rbf');
    end
    yp = sign(y_sum);
    y_pred(i) = yp;
end

prediction = y_pred;

end
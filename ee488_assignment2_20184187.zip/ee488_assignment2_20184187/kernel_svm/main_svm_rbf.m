clear;clc;
%% Your parameter here %%
T = 500; % The number of iteration
%% Codes %%
[x_train,y_train,x_test,y_test] = createDataset('train.csv','test.csv');
alpha = train_rbf(x_train,y_train,T);
acc = test_rbf(x_test,y_test,x_train,alpha);
plot_svm_rbf(x_train,y_train,x_test,y_test,alpha);
function [avg_alpha] = train_rbf(x_train,y_train,T)
%% Arguments %%
% x_train: training data
% y_train: training label
% T: the number of iteration
% theta: weight parameter
%% Your code here %%
lamda = 1;                          % Set lambda value
m = length(y_train);
beta = zeros(m,1);                  % Initialize value of beta
alpha = zeros(m,T);

for t = 1:T
    alpha(:,t) = beta/(lamda*t);    % Calculate new alpha
    i = randi([1 m],1,1);           % Choose uniformly a data sample
    
    % Mapping with RBF kernel
    K = zeros(m,1);
    for j = 1:m
        K(j) = svmkernel(x_train(i,:),x_train(j,:),'rbf');
    end
    if y_train(i)*sum(alpha(:,t).*K) < 1
        beta(i) = beta(i) + y_train(i);
    else
        beta(i) = beta(i);
    end
end  

avg_alpha = sum(alpha,2)/T; % Output vector

end


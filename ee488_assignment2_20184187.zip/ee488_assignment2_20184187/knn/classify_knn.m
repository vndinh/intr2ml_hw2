function class = classify_knn(x_input,x_train,y_train,k)
%% Arguments %%
% x_input: inputs to classify
% x_train: training data
% y_train: training label
% k: number of nearest neighbor
% class: predicted class
%% Your code here %%
m = size(x_train,1);    % Number of the training data points
p = size(x_input,1);    % Number of the test data points

% Calculating distance by norm 2
D = zeros(m,p);
for i = 1:p
    for j = 1:m
        d = x_input(i,:) - x_train(j,:);
        D(j,i) = d * d';
    end
end

% Finding the index of k nearest points in the training set
[~,Didx] = sort(D,1);
Kidx = Didx(1:k,:);

% Mapping the label of k nearest training points
Klabel = zeros(k,p);
for i = 1:p
    for j = 1:k
       Klabel(j,i) = y_train(Kidx(j,i));
    end
end

% Major vote
Kvote = sum(Klabel,1);
class = sign(Kvote);

end

function [acc] = test_knn(class,y_test)
%% Arguments %%
% class: predicted label
% y_test: test label
% acc: accuracy
%% Your code here %%
acc = sum(class' == y_test) / length(y_test) * 100;
fprintf('Accuracy of k-NN: acc = %f %% \n', acc);

end
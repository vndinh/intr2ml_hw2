clear;clc;close all;
%% Your parameter here %%
% Should choose the value of k is an odd number
% and not greater than the half of the training data size
k = 1;
%% Codes %%
[x_train,y_train,x_test,y_test] = createDataset('train.csv','test.csv');
[class] = classify_knn(x_test,x_train,y_train,k);
[acc] = test_knn(class,y_test);
plot_knn(x_train,y_train,x_test,y_test,k);
